# ccopt saved state skew_groups.tcl.gz

## Tcl for skew_group
# Skew Group Mode: all
switch_ccopt_skew_group_mode -create all
# Skew Group: all
create_ccopt_skew_group -name all -generated  -auto_sinks -sources {{clk rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: default
switch_ccopt_skew_group_mode -create default
# Skew Group: clk/syn_constraints
create_ccopt_skew_group -name clk/syn_constraints -from_clocks {clk} -from_constraint_modes {syn_constraints} -from_delay_corners {CORNER_ss_125 CORNER_ff_-55} -target_insertion_delay 1.000 -auto_sinks -sources {clk}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: stagedepth
switch_ccopt_skew_group_mode -create stagedepth
# Skew Group: stagedepth
create_ccopt_skew_group -name stagedepth -generated  -auto_sinks -sources {{clk rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group

# Switch back to default mode.
switch_ccopt_skew_group_mode default